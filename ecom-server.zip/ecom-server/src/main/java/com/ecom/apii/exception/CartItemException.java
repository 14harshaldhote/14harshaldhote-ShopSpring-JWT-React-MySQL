package com.ecom.apii.exception;

public class CartItemException extends Exception {
	
	public CartItemException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
