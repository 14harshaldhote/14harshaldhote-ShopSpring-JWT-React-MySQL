package com.ecom.apii.response;

public class CreatePaymentLinkResponse {
	
	

}
