package com.ecom.apii.exception;

public class OrderException extends Exception {
	
	public OrderException(String message) {
		super(message);
	}

}
