package com.ecom.apii.service;

import com.ecom.apii.modal.OrderItem;

public interface OrderItemService {
	
	public OrderItem createOrderItem(OrderItem orderItem);

}
