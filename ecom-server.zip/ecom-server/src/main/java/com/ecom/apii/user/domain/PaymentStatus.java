package com.ecom.apii.user.domain;

public enum PaymentStatus {

	PENDING,
    PROCESSING,
    COMPLETED,
    FAILED
}
