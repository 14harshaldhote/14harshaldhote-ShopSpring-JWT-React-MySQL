package com.ecom.apii.request;

public class DeleteProductRequest {
	
//	private Long 

}
