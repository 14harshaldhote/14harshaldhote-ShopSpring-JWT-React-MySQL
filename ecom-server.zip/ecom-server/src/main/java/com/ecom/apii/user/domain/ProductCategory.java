package com.ecom.apii.user.domain;

public enum ProductCategory {
	MALE,
	FEMALE

}
