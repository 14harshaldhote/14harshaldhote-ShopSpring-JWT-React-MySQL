package com.ecom.apii.user.domain;

public enum ProductSubCategory {
	SHIRT,
	TSHIRT,
	SHOES,
	PAINT,
	SAREE,
	KURTA,
	WATCH

}
